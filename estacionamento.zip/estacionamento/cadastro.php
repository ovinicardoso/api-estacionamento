<?php
// Conectar ao banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "estacionamento";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Lógica para adicionar, editar e excluir
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Adicionar novo registro
    if (isset($_POST['add'])) {
        $nome_usuario = $_POST['nome_usuario'];
        $telefone = $_POST['telefone'];
        $email = $_POST['email'];
        $ns_cartao = $_POST['ns_cartao'];

        // Inserir dados na tabela pessoa
        $sql_pessoa = "INSERT INTO pessoa (Nome_Usuario, Telefone, Email) VALUES ('$nome_usuario', '$telefone', '$email')";
        if ($conn->query($sql_pessoa) === TRUE) {
            $id_pessoa = $conn->insert_id; // Obtém o ID da pessoa inserida
            
            // Inserir dados na tabela cartao
            $sql_cartao = "INSERT INTO cartao (NS_Cartao, ID_Pessoa) VALUES ('$ns_cartao', '$id_pessoa')";
            $conn->query($sql_cartao);
        }
    }

    // Editar registro
    if (isset($_POST['edit'])) {
        $id_pessoa = $_POST['id_pessoa'];
        $nome_usuario = $_POST['nome_usuario'];
        $telefone = $_POST['telefone'];
        $email = $_POST['email'];
        $ns_cartao = $_POST['ns_cartao'];
        $id_cartao = $_POST['id_cartao'];

        // Atualizar dados na tabela pessoa
        $sql_pessoa = "UPDATE pessoa SET Nome_Usuario='$nome_usuario', Telefone='$telefone', Email='$email' WHERE ID_Pessoa='$id_pessoa'";
        $conn->query($sql_pessoa);

        // Atualizar dados na tabela cartao
        $sql_cartao = "UPDATE cartao SET NS_Cartao='$ns_cartao' WHERE ID_Cartao='$id_cartao'";
        $conn->query($sql_cartao);
    }

    // Excluir registro
    if (isset($_POST['delete'])) {
        $id_pessoa = $_POST['id_pessoa'];
        $id_cartao = $_POST['id_cartao'];

        // Excluir da tabela cartao
        $sql_cartao = "DELETE FROM cartao WHERE ID_Cartao='$id_cartao'";
        $conn->query($sql_cartao);

        // Excluir da tabela pessoa
        $sql_pessoa = "DELETE FROM pessoa WHERE ID_Pessoa='$id_pessoa'";
        $conn->query($sql_pessoa);
    }
}

// Selecionar registros de pessoa e cartão
$sql = "SELECT pessoa.ID_Pessoa, pessoa.Nome_Usuario, pessoa.Telefone, pessoa.Email, cartao.ID_Cartao, cartao.NS_Cartao 
        FROM pessoa 
        JOIN cartao ON pessoa.ID_Pessoa = cartao.ID_Pessoa";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StarPark - Gerenciamento de Cadastros</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Estilos para os botões */
        .button {
            padding: 5px 5px;
            margin: 5px;
            border: noeno;
            border-radius: 5px;
            background-color: #007bff; /* Azul */
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #0056b3; /* Azul escuro */
        }
        /* Estilos para a tabela */
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 5px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        /* Estilos para o botão de voltar */
        .btn-back {
            margin: 20px 0;
            display: inline-block;
            padding: 10px 15px;
            background-color: #6c757d; /* Cinza */
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn-back:hover {
            background-color: #5a6268; /* Cinza escuro */
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include 'sidebar.php'; ?>
        <div class="content">
            <h1>Gerenciamento de Cadastros</h1>
            <link rel="stylesheet" href="sidebar_style.css">
            <!-- Formulário para Adicionar -->
            <form method="POST">
                <h2>Adicionar Nova Pessoa e Cartão</h2>
                <label>Nome:</label><input type="text" name="nome_usuario" required><br>
                <label>Telefone:</label><input type="text" name="telefone" required><br>
                <label>Email:</label><input type="email" name="email" required><br>
                <label>Número de Série do Cartão:</label><input type="text" name="ns_cartao" required><br>
                <input type="submit" name="add" value="Adicionar" class="button">
            </form>

            <!-- Botão para voltar à dashboard -->

            <!-- Exibição da lista -->
            <h2>Lista de Pessoas e Cartões</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID Pessoa</th>
                        <th>Nome</th>
                        <th>Telefone</th>
                        <th>Email</th>
                        <th>ID Cartão</th>
                        <th>Número de Série</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['ID_Pessoa'] ?></td>
                                <td><?= $row['Nome_Usuario'] ?></td>
                                <td><?= $row['Telefone'] ?></td>
                                <td><?= $row['Email'] ?></td>
                                <td><?= $row['ID_Cartao'] ?></td>
                                <td><?= $row['NS_Cartao'] ?></td>
                                <td>
                                    <form method="POST" style="display:inline-block;">
                                        <input type="hidden" name="id_pessoa" value="<?= $row['ID_Pessoa'] ?>">
                                        <input type="hidden" name="id_cartao" value="<?= $row['ID_Cartao'] ?>">
                                        <input type="text" name="nome_usuario" value="<?= $row['Nome_Usuario'] ?>" required>
                                        <input type="text" name="telefone" value="<?= $row['Telefone'] ?>" required>
                                        <input type="email" name="email" value="<?= $row['Email'] ?>" required>
                                        <input type="text" name="ns_cartao" value="<?= $row['NS_Cartao'] ?>" required>
                                        <input type="submit" name="edit" value="Editar" class="button">
                                    </form>
                                    <form method="POST" style="display:inline-block;">
                                        <input type="hidden" name="id_pessoa" value="<?= $row['ID_Pessoa'] ?>">
                                        <input type="hidden" name="id_cartao" value="<?= $row['ID_Cartao'] ?>">
                                        <input type="submit" name="delete" value="Excluir" class="button" style="background-color: #dc3545;"> <!-- Vermelho -->
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7">Nenhum registro encontrado.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
