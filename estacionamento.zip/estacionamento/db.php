<?php
// Defina suas credenciais do banco de dados
$servidor = "localhost";
$usuario = "root"; // Substitua pelo seu usuário do banco
$senha = ""; // Substitua pela sua senha do banco
$banco = "estacionamento"; // Nome do seu banco de dados

// Crie a conexão
$conexao = new mysqli($servidor, $usuario, $senha, $banco);

// Verifique a conexão
if ($conexao->connect_error) {
    die("Erro de conexão: " . $conexao->connect_error);
}
?>
