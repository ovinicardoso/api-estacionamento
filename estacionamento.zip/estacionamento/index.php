<?php
// Redireciona para a tela de login
header('Location: login.php');
exit;
?>
