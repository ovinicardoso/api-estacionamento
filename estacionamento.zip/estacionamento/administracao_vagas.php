<?php
session_start();
include 'db.php'; // Inclua o arquivo de conexão ao banco de dados

// Consultar o estado das vagas do banco de dados
$query = "SELECT ID_Vaga, Ocupado FROM vaga"; // Supondo que sua tabela se chama 'vaga'
$result = $conexao->query($query);

$vagas = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $vagas[$row['ID_Vaga']] = $row['Ocupado'] == 1; // 1 significa ocupado
    }
} else {
    echo "Erro ao consultar as vagas: " . $conexao->error;
}

// Atualizando a vaga quando o formulário é enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['vaga_id'])) {
    $vaga_id = $_POST['vaga_id'];
    $status = $_POST['status']; // 'ocupada' ou 'livre'
    
    // Atualizar o status da vaga no banco de dados
    $query_update = "UPDATE vaga SET Ocupado = ? WHERE ID_Vaga = ?";
    $stmt = $conexao->prepare($query_update);
    $stmt->bind_param("is", $status, $vaga_id);
    
    if ($stmt->execute()) {
        // Atualizar a variável de estado após a atualização
        $vagas[$vaga_id] = $status == 1;
    } else {
        echo "Erro ao atualizar o status da vaga: " . $conexao->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StarPark - Administração de Vagas</title>
    <link rel="stylesheet" href="sidebar_style.css"> <!-- Estilo da barra lateral -->
    <style>
        body {
            background-color: #f0f4f8; /* Cor de fundo suave */
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            width: 100%;
        }
        .sidebar {
            width: 20%;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            display: flex;
            flex-direction: column;
            height: 100vh;
            position: fixed;
        }
        .sidebar h2 {
            margin-bottom: 30px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            display: block;
            margin-bottom: 15px;
        }
        .sidebar a:hover {
            background-color: #34495e;
            padding: 10px;
            border-radius: 5px;
        }
        .content {
            margin-left: 20%;
            padding: 20px;
            width: 80%;
        }
        h1 {
            color: #007bff;
            margin-bottom: 20px;
        }
        .vagas-container {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
        }
        .vaga {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100px;
            height: 100px;
            margin: 10px;
            border-radius: 10px;
            font-size: 20px;
            position: relative;
            color: white;
        }
        .vaga.ocupada {
            background-color: red;
        }
        .vaga.livre {
            background-color: green;
        }
        .carro {
            width: 50px;
            height: 30px;
            background-color: #333;
            position: absolute;
            bottom: 5px;
            left: 50%;
            transform: translateX(-50%);
        }
        .button-back {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .button-back:hover {
            background-color: #0056b3;
        }
        form {
            margin-top: 10px;
        }
        select {
            padding: 5px;
            border-radius: 5px;
            margin-right: 5px;
        }
        button[type="submit"] {
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>StarPark</h2>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="cadastro.php">Gerenciar Cadastros</a></li>
            <li><a href="administracao_vagas.php">Administração de Vagas</a></li>
            <li><a href="logout.php">Sair</a></li>
        </div>
        <div class="content">
            <h1>Administração de Vagas</h1>
            <div class="vagas-container">
                <?php foreach ($vagas as $vaga_id => $ocupada): ?>
                    <div class="vaga <?php echo $ocupada ? 'ocupada' : 'livre'; ?>">
                        Vaga <?php echo $vaga_id; ?>
                        <?php if ($ocupada): ?>
                        <?php endif; ?>
                    </div>
                    <form method="POST" action="">
                        <input type="hidden" name="vaga_id" value="<?php echo $vaga_id; ?>">
                        <select name="status">
                            <option value="1" <?php echo $ocupada ? 'selected' : ''; ?>>Ocupada</option>
                            <option value="0" <?php echo !$ocupada ? 'selected' : ''; ?>>Livre</option>
                        </select>
                        <button type="submit">Atualizar</button>
                    </form>
                <?php endforeach; ?>
            </div>
            <button class="button-back" onclick="window.location.href='dashboard.php'">Voltar para Dashboard</button>
        </div>
    </div>
</body>
</html>
