<?php
session_start(); // Inicia a sessão
?>

<!DOCTYPE html>
<html lang="pt-BR"> <!-- Alterado para o idioma português -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StarPark - Dashboard</title>
    <link rel="stylesheet" href="sidebar_style.css"> <!-- Atualizei para o nome do arquivo CSS correto -->
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>Menu</h2>
            <ul>
            <li><a href="dashboard.php">Dashboard</a></li> <!-- Link para a dashboard -->
            <li><a href="cadastro.php">Gerenciar Cadastros</a></li> <!-- Botão para gerenciar cadastros -->            
            <li><a href="administracao_vagas.php">Administração de Vagas</a></li> <!-- Link para a administração de vagas -->
            <li><a href="logout.php">Sair</a></li>
                <!-- Adicione outros links do menu aqui -->
            </ul>
        </div>
        <div class="content">
            <h1>Bem-vindo ao StarPark!</h1>
            <p class="welcome-message">Estamos felizes em tê-lo aqui. Gerencie suas operações de estacionamento com facilidade!</p>
        </div>
    </div>
</body>
</html>
