<div class="sidebar">
    <h2>StarPark</h2>
    <ul>
    <li><a href="dashboard.php">Dashboard</a></li> <!-- Link para a dashboard -->
    <li><a href="cadastro.php">Gerenciar Cadastros</a></li> <!-- Botão para gerenciar cadastros -->            
    <li><a href="administracao_vagas.php">Administração de Vagas</a></li> <!-- Link para a administração de vagas -->
    <li><a href="logout.php">Sair</a></li>
    </ul>
</div>
