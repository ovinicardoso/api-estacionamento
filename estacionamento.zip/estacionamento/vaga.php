<?php
// Iniciar a sessão
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    // Se não estiver logado, redireciona para a página de login
    header("Location: login.php");
    exit();
}

// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "estacionamento";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Consultas ao banco de dados
$sql = "SELECT * FROM vaga";
$result = $conn->query($sql);

$sql = "SELECT * FROM cartao";
$result_cartao = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vagas</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            padding: 20px;
        }
        .vaga-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .vaga {
            background-color: white;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 200px;
        }
        .button-container {
            margin-top: 20px;
        }
        .button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Informações das Vagas</h1>

    <div class="vaga-container">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="vaga">
                <h2>Vaga <?php echo $row['id']; ?></h2>
                <p>Status: <?php echo $row['status']; ?></p>
                <?php if ($row['status'] == "Ocupada"): ?>
                    <p>Carro: 
                        <?php
                        // Procurar o carro associado a esta vaga
                        $carro = "Nenhum carro associado.";
                        while ($cartao = $result_cartao->fetch_assoc()) {
                            if ($cartao['vaga_id'] == $row['id']) {
                                $carro = $cartao['nome'] . " (Entrada: " . $cartao['entrada'] . ", Saída: " . $cartao['saida'] . ")";
                                break;
                            }
                        }
                        echo $carro;
                        ?>
                    </p>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>

    <div class="button-container">
        <a class="button" href="administracao.php">Ir para Administração</a>
        <a class="button" href="dashboard.php">Voltar ao Dashboard</a>
    </div>
</body>
</html>

<?php
$conn->close();
?>
